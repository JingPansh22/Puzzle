import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;

import java.util.Arrays;

import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;

import java.util.Arrays;

public class GameGrid extends GridPane {
    private GameCell[][] cells;
    private int gridSize;
    private int columnSize;
    private int[][] gridPositions;  // **calculate C(n,2) coordinates**

    public GameGrid(int size, int gridSizePerBox) {  //
        this.cells = new GameCell[gridSize][gridSize];
        this.columnSize = size;
        this.gridPositions = new int[size][size];  // initialize `gridPositions`

        initializeCells();
        initializeGridPositions(size, gridSizePerBox);  //
        renderGrid();
    }


    public int[][] getGridPositions() {
        return gridPositions;
    }

    public GridPane createGrid() {
        GridPane gridPane = new GridPane();
        gridPane.setHgap(5);
        gridPane.setVgap(5);

        for (int i = 0; i < gridSize; i++) {
            for (int j = 0; j < columnSize; j++) {
                gridPane.add(cells[i][j], j, i);
            }
        }
        return gridPane;
    }

    private void initializeCells() {
        for (int i = 0; i < gridSize; i++) {
            for (int j = 0; j < columnSize; j++) {
                cells[i][j] = new GameCell();  // fill all cells to avoid UI empty
            }
        }
    }

    private void renderGrid() {
        this.setHgap(5);
        this.setVgap(5);
        for (int i = 0; i < gridSize; i++) {
            for (int j = 0; j < columnSize; j++) { //
                this.add(cells[i][j], j, i);
            }
        }
    }

    /**
     * initialize`gridPositions` to C(n,2) crossing position
     */
    private void initializeGridPositions(int totalGrids, int gridSizePerBox) {
        gridPositions = new int[totalGrids][totalGrids];

        int offset = 1; // offset for downwards or right to +1

        for (int grid1 = 0; grid1 < totalGrids; grid1++) {
            for (int grid2 = grid1 + 1; grid2 < totalGrids; grid2++) {
                int rowIndex = 0, colIndex = 0;

                if (totalGrids == 4) {
                    if (grid1 == 0) {
                        rowIndex = 2 + offset;
                        colIndex = (grid2 - 1) * gridSizePerBox + 2 + offset;
                    } else if (grid1 == 1) {
                        rowIndex = 6 + offset;
                        colIndex = (grid2 - 2) * gridSizePerBox + 2 + offset;
                    } else {
                        rowIndex = 2 + gridSizePerBox * 2 + offset;
                        colIndex = 2 + offset;
                    }
                } else if (totalGrids == 3) {
                    if (grid1 == 0) {
                        rowIndex = 2 + offset;
                        colIndex = (grid2 - 1) * gridSizePerBox + 2 + offset;
                    } else if (grid2 == totalGrids - 1) {
                        rowIndex = (grid1 - 1) * gridSizePerBox + 2 + gridSizePerBox + offset;
                        colIndex = 2 + offset;
                    }
                }

                gridPositions[grid1][grid2] = rowIndex;
                gridPositions[grid2][grid1] = colIndex;
            }
        }

        // Debug
        System.out.println("Debug: Grid Positions (after offset):");
        for (int i = 0; i < totalGrids; i++) {
            System.out.println(Arrays.toString(gridPositions[i]));
        }
    }

}