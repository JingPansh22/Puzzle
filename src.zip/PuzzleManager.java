import java.util.*;

public class PuzzleManager {
    private int totalGrids;
    private int gridSizePerBox;
    private int rows;
    private int cols;
    private String difficulty;

    private GameCell[][] puzzleGrid;
    private String[][] solutionGrid;

    private List<String> clues;
    private List<String> hints;
    private List<String> story;
    private List<String> answers;

    private List<GameAction> actionHistory;
    private long startTime;
    private long endTime;

    private String[] rowTitles;
    private String[] colTitles;
    private String[][] subTitles;
    private int hintIndex = 0;

    private List<int[]> gridRelationships = new ArrayList<>();;


    public PuzzleManager(int totalGrids, int gridSizePerBox, String difficulty) {
        this.totalGrids = totalGrids;
        this.gridSizePerBox = gridSizePerBox;
        this.rows = totalGrids * gridSizePerBox;
        this.cols = gridSizePerBox;
        this.difficulty = difficulty;
        this.gridRelationships = new ArrayList<>();

        this.puzzleGrid = new GameCell[rows][cols];
        this.solutionGrid = new String[rows][cols];

        this.clues = new ArrayList<>();
        this.hints = new ArrayList<>();
        this.story = new ArrayList<>();
        this.answers = new ArrayList<>();
        this.actionHistory = new ArrayList<>();
    }

    public void initializePuzzle() {
        System.out.println("Initializing PuzzleManager with " + totalGrids + " grids, each "
                + gridSizePerBox + "x" + gridSizePerBox + ", Difficulty: " + difficulty);

        loadPuzzleData();  // parse CSV
        parseGridRelationships();

        loadClues();
        loadHints();
        //loadStory();
        startGame();

        System.out.println(" Puzzle initialized with " + rows + " rows and " + cols + " columns.");
    }

    // add these two for add subtitles to the grid
    private Map<String, Integer> rowTitleToIndex;
    private Map<String, Integer> colTitleToIndex;

    public Map<String, Integer> getRowTitleIndex() {
        return rowTitleToIndex;
    }

    public Map<String, Integer> getColTitleIndex() {
        return colTitleToIndex;
    }

    private void loadPuzzleData() {
        List<String[]> csvData = CSVLoader.loadPuzzle("puzzle.csv");
        if (csvData.isEmpty()) throw new RuntimeException(" CSV 为空!");

        // reading the 1st line = heading ling
        String[] headers = csvData.get(0);
        int numCategories = headers.length;

        //！！！！remove BOM and extra space which gave me trouble
        for (int i = 0; i < headers.length; i++) {
            headers[i] = headers[i].replace("\uFEFF", "").trim();
        }

        totalGrids = numCategories;

        colTitles = Arrays.copyOf(headers, totalGrids - 1);

        // rowTitles（get from totalGrids-1 ）
        rowTitles = new String[totalGrids - 1];
        for (int i = 0; i < rowTitles.length; i++) {
            rowTitles[i] = headers[(totalGrids - 1) - i];
        }

        // build HashMap index
        rowTitleToIndex = new HashMap<>();
        colTitleToIndex = new HashMap<>();

        System.out.println("Debug: rowTitles = " + Arrays.toString(rowTitles));
        System.out.println("Debug: colTitles = " + Arrays.toString(colTitles));

        rowTitleToIndex.clear();
        colTitleToIndex.clear();

        for (int i = 0; i < rowTitles.length; i++) {
            rowTitleToIndex.put(rowTitles[i].trim(), i);
            System.out.println("Mapped rowTitleToIndex: " + rowTitles[i] + " -> " + i);
        }

        for (int i = 0; i < colTitles.length; i++) {
            colTitleToIndex.put(colTitles[i].trim(), i);
            System.out.println("Mapped colTitleToIndex: " + colTitles[i] + " -> " + i);
        }


        // get `columnData`
        List<String> columnData = new ArrayList<>();
        for (int colIndex = 0; colIndex < csvData.get(0).length; colIndex++) {
            for (int i = 1; i < csvData.size(); i++) {  // skip header
                String value = csvData.get(i)[colIndex];
                columnData.add(value);
            }
        }

        // subTitles: save as column
        // initialize subTitles**
        subTitles = new String[numCategories][csvData.size() - 1];
        for (int i = 1; i < csvData.size(); i++) {
            String[] rowData = csvData.get(i);
            for (int j = 0; j < numCategories; j++) {
                subTitles[j][i - 1] = rowData[j];
            }
        }
        // debug
        System.out.println("Debug: subTitles.length = " + subTitles.length);
        for (int i = 0; i < subTitles.length; i++) {
            System.out.println("Debug: subTitles[" + i + "] = " + Arrays.toString(subTitles[i]));
        }

        System.out.println(" Checking Puzzle Data:");
        System.out.println("Headers: " + Arrays.toString(headers));
        System.out.println("Calculated totalGrids: " + totalGrids);
        System.out.println("Calculated rowTitles: " + Arrays.toString(rowTitles));
        System.out.println("Calculated colTitles: " + Arrays.toString(colTitles));
        System.out.println("Row Title Index Mapping: " + rowTitleToIndex);
        System.out.println("Col Title Index Mapping: " + colTitleToIndex);
        System.out.println("Calculated subTitles (by column): " + Arrays.deepToString(subTitles));
    }





    private void parseGridRelationships() {
        gridRelationships.clear();
        for (int i = 0; i < totalGrids; i++) {
            for (int j = i + 1; j < totalGrids; j++) {
                gridRelationships.add(new int[]{i, j}); // ✅ 确保正确匹配
            }
        }
        // debug
        System.out.println("Grid Relationships: " + gridRelationships);
        System.out.println("Caculated Grid Relationships: " + gridRelationships);
    }


    private void initializeGrid() {
        rows = subTitles.length * gridSizePerBox;
        cols = gridSizePerBox;
        puzzleGrid = new GameCell[rows][cols];
        solutionGrid = new String[rows][cols];

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                puzzleGrid[i][j] = new GameCell();
                solutionGrid[i][j] = "❌";
            }
        }
    }

    public List<int[]> getGridRelationships() { return gridRelationships; }

    public String[] getRowTitles() {
        return rowTitles;
    }

    public String[] getColTitles() {
        return colTitles;
    }

    public String[][] getSubTitles() {
        return subTitles;
    }


    public void loadClues() {
        clues = CSVLoader.loadClues("clues.csv");
        if (clues == null) {
            clues = new ArrayList<>();
        }
    }

    public void loadHints() {
        hints = CSVLoader.loadHints("hints.csv");
    }
/*暂时听一下
    public void loadStory() {
        story = CSVLoader.loadStory("story.csv");
    }

    public void loadAnswers() {
        answers = CSVLoader.loadAnswers("answers.csv");
    }
    */


    public String getNextHint() {
        if (hintIndex >= 0 && hintIndex < hints.size()) {
            return hints.get(hintIndex++);
        }
        return "No more hints available!";
    }

    public void undoLastAction() {
        if (!actionHistory.isEmpty()) {
            GameAction lastAction = actionHistory.remove(actionHistory.size() - 1);
            lastAction.undo();
            System.out.println("Undo last action.");
        } else {
            System.out.println("No actions to undo.");
        }
    }

    public void clearErrors() {
        /*报错
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                if (puzzleGrid[i][j].getState() == 0) {
                    puzzleGrid[i][j].setState(2);
                }
            }
        }
         */
        System.out.println(" All errors cleared.");
    }

    public void restartGame() {
        initializePuzzle();
        actionHistory.clear();
        System.out.println(" Puzzle restarted.");
    }


    public void startGame() {
        startTime = System.currentTimeMillis();
    }

    public void stopGame() {
        endTime = System.currentTimeMillis();
    }

    public long getElapsedTime() {
        return (endTime - startTime) / 1000;
    }

    /*暂时听一下
        public boolean submitPuzzle() {
            System.out.println("🔍 Checking puzzle solution...");
            if (checkSolution()) {
                stopGame();
                long elapsedTime = getElapsedTime();
                System.out.println("Correct! Time: " + elapsedTime + " seconds!");
                return true;
            } else {
                System.out.println("Incorrect! Some answers are wrong.");
                return false;
            }
        }

        private boolean checkSolution() {
            for (int i = 0; i < rows; i++) {
                for (int j = 0; j < cols; j++) {
                    if (!puzzleGrid[i][j].isCorrect(solutionGrid[i][j])) {
                        return false;
                    }
                }
            }
            return true;
        }
    */
    public int getTotalGrids() {
        return totalGrids;
    }

    public int getGridSizePerBox() {
        return this.gridSizePerBox;
    }

    public String getDifficulty(){
        return this.difficulty;
    }

}