import java.util.List;

public class LogicSolver {
    public static boolean isCorrect(String drug, String condition, List<String[]> puzzleData) {
        for (String[] row : puzzleData) {
            if (row[1].equals(drug) && row[2].equals(condition)) {
                return true;
            }
        }
        return false;
    }
}
