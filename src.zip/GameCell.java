import javafx.scene.control.Button;

public class GameCell extends Button {
    private int state; // 0 = ❌, 1 = ⭕, 2 = blank
    private static final String[] STATES = {"❌", "⭕", ""};

    private boolean isCorrect; // mark for correctness

    public GameCell() {
        super(STATES[2]); // all cells initially are blank
        this.state = 2;
        this.isCorrect = false;
        this.setOnAction(e -> toggleState());
    }

    // toggle state from ❌ → ⭕ →blank
    private void toggleState() {
        state = (state + 1) % 3;
        setText(STATES[state]);
    }

    public void setState(int newState) {
        this.state = newState;
        setText(STATES[state]);
    }

    public int getState() {
        return this.state;
    }
    public void clear() {
        setState(2); // set to blank
    }

}


