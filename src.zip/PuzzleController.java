import javafx.fxml.FXML;
import javafx.geometry.HPos;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.StackPane;

import java.io.File;
import java.util.*;

public class PuzzleController {
    @FXML private StackPane logicGridContainer;
    @FXML private GridPane mainGrid;
    @FXML private Label clueLabel;
    @FXML private Button undoButton, hintButton, clearButton, restartButton, submitButton;

    @FXML private ListView clueListView;
    @FXML private TextArea storyTextArea;
    @FXML private TextArea notesTextArea;
    @FXML private TableView answersTableView;

    private PuzzleManager puzzleManager;
    private GameGrid gameGrid;

    @FXML
    public void initialize() {
        if (mainGrid == null) {
            mainGrid = new GridPane();
            mainGrid.setHgap(5);
            mainGrid.setVgap(5);
        }

        if (logicGridContainer != null && !logicGridContainer.getChildren().contains(mainGrid)) {
            logicGridContainer.getChildren().add(mainGrid); // put mainGrid into StackPane
        }

        System.out.println("PuzzleController initialized, mainGrid added to logicGridContainer.");

        // Load hints
        List<String> storyData = CSVLoader.loadHints("hints.csv");
        loadClues(); // not connected to difficulty yet!!!


        System.out.println("Puzzle data successfully loaded into UI.");
    }



    private void loadClues() {
        try {
            List<String> clues = CSVLoader.loadClues("clues.csv");

            if (!clues.isEmpty()) {
                clueListView.getItems().addAll(clues); //add clues to ListView
            }
            System.out.println("Clues loaded successfully: " + clues);
        } catch (Exception e) {
            System.err.println("Clues loaded failed " + e.getMessage());
        }
    }

    public void initializeGame(String gridSize, String difficulty) {
        String[] parts = gridSize.split("x");
        int baseCount = Integer.parseInt(parts[0]); // 3 or 4
        System.out.println("baseCount: " + baseCount); // debug
        int gridSizePerBox = Integer.parseInt(parts[1]);
        System.out.println("gridSizePerBox: " + gridSizePerBox); // debug
        int totalGrids = baseCount; // should not be a fixed number remember

        puzzleManager = new PuzzleManager(totalGrids, gridSizePerBox, difficulty);
        puzzleManager.initializePuzzle();

        //int gridSize = puzzleManager.getGridSizePerBox() * puzzleManager.getTotalGrids();
        //gameGrid = new GameGrid(gridSize); // 传入 gridSize/
        initializeGameGrid();
        renderGrid();
    }
    public void initializeGameGrid() {
        int totalGrids = puzzleManager.getTotalGrids();
        int gridSizePerBox = puzzleManager.getGridSizePerBox(); // to get gridSizePerBox

        gameGrid = new GameGrid(totalGrids, gridSizePerBox);
    }


    private void renderGrid() {
        mainGrid = new GridPane();
        mainGrid.setHgap(5);
        mainGrid.setVgap(5);
        mainGrid.setGridLinesVisible(false); // for me to see the grid clearly


        int[][] gridPositions = gameGrid.getGridPositions();
        int gridSizePerBox = puzzleManager.getGridSizePerBox();
        int totalGrids = puzzleManager.getTotalGrids();

        Map<String, Integer> rowTitleToIndex = puzzleManager.getRowTitleIndex();
        Map<String, Integer> colTitleToIndex = puzzleManager.getColTitleIndex();

        String[] colTitles = puzzleManager.getColTitles();
        String[] rowTitles = puzzleManager.getRowTitles();
        String[][] subTitles = puzzleManager.getSubTitles();

        System.out.println("Drawing grids: totalGrids = " + totalGrids + ", gridSizePerBox = " + gridSizePerBox);

        // draw col titles
        for (int i = 0; i < colTitles.length; i++) {
            Label colTitleLabel = new Label(colTitles[i]);
            colTitleLabel.setStyle("-fx-font-weight: bold; -fx-background-color: black; -fx-text-fill: white;");
            colTitleLabel.setMinHeight(40);
            mainGrid.add(colTitleLabel, 4 + i * gridSizePerBox, 0);
            GridPane.setColumnSpan(colTitleLabel, gridSizePerBox);
            colTitleLabel.setAlignment(Pos.CENTER);
        }

        // draw row titles
        for (int i = 0; i < rowTitles.length; i++) {
            Label rowTitleLabel = new Label(rowTitles[i]);
            rowTitleLabel.setStyle("-fx-font-weight: bold; -fx-background-color: black; -fx-text-fill: white;");
            rowTitleLabel.setMinWidth(40);
            mainGrid.add(rowTitleLabel, 1, 2 + i * gridSizePerBox);
            GridPane.setRowSpan(rowTitleLabel, gridSizePerBox);
            rowTitleLabel.setRotate(-90);
        }

        // subtitles
        // check colTitleToIndex & rowTitleToIndex first
        System.out.println("Debug: colTitleToIndex = " + colTitleToIndex);
        System.out.println("Debug: rowTitleToIndex = " + rowTitleToIndex);
        System.out.println("Debug: colTitleToIndex.get(\"Names\") = " + colTitleToIndex.get("Names"));
        System.out.println("Debug: rowTitleToIndex.get(\"Names\") = " + rowTitleToIndex.get("Names"));
        for (String key : colTitleToIndex.keySet()) {
            System.out.println("Debug: colTitleToIndex key = '" + key + "'");
        }
        for (String key : colTitleToIndex.keySet()) {
            System.out.println("Debug: colTitleToIndex key = '" + key + "' (Hex: " + key.chars()
                    .mapToObj(c -> String.format("%02X", c))
                    .reduce((a, b) -> a + " " + b)
                    .orElse("") + ")");
        }

        // matching subtitles!!!
        for (int subIndex = 0; subIndex < subTitles.length; subIndex++) {
            String category;

            // coltitles first and then match rowtitles
            if (subIndex < colTitles.length) {
                category = colTitles[subIndex];
            } else {
                category = rowTitles[subIndex - colTitles.length];
            }

            System.out.println("Debug: Checking subTitles[" + subIndex + "] for category: " + category);

            boolean isFilled = false; // to check whether it is filled

            if (colTitleToIndex.containsKey(category)) {
                System.out.println("Found " + category + " in colTitleToIndex!");

                // subtitle to put under columns
                int colStart = colTitleToIndex.get(category) * gridSizePerBox + 3;
                int rowStart = 1; // fixed starting point

                for (int i = 0; i < subTitles[subIndex].length; i++) {
                    String value = subTitles[subIndex][i];
                    Label dataLabel = new Label(value);
                    dataLabel.setStyle("-fx-font-weight: bold;");
                    dataLabel.setRotate(90);  //
                    dataLabel.setMaxWidth(40); // make sure the lables won't impact the layout
                    dataLabel.setPrefHeight(120); // ????

                    System.out.println("Debug: Adding `" + category + " → under` subTitle '" + value + "' at (" + rowStart + ", " + (colStart + i) + ")");

                    mainGrid.add(dataLabel, colStart + i, rowStart);
                    GridPane.setHalignment(dataLabel, HPos.CENTER);
                }
                isFilled = true; // marking filled
            }

            if (rowTitleToIndex.containsKey(category)) {
                System.out.println("Found " + category + " in rowTitleToIndex!");

                // subtitle to put right columns
                int colStart = 2;  // fix starting point on the row title right side!!!
                int rowStart = rowTitleToIndex.get(category) * gridSizePerBox + 3;  //

                for (int i = 0; i < subTitles[subIndex].length; i++) {
                    String value = subTitles[subIndex][i];
                    Label dataLabel = new Label(value);
                    dataLabel.setStyle("-fx-font-weight: bold;");

                    System.out.println("Debug: Adding `" + category + " → rightside` subTitle '" + value + "' at (" + (rowStart + i) + ", " + colStart + ")");

                    mainGrid.add(dataLabel, colStart, rowStart + i);
                    GridPane.setHalignment(dataLabel, HPos.CENTER);
                }
                isFilled = true; // mark filled
            }

            if (!isFilled) {
                System.out.println("Error: " + category + " not found in colTitleToIndex or rowTitleToIndex!");
            }
        }

        //  generate `C(n,2)`grids**
        for (int grid1 = 0; grid1 < totalGrids; grid1++) {
            for (int grid2 = grid1 + 1; grid2 < totalGrids; grid2++) {
                int baseRow = gridPositions[grid1][grid2];
                int baseCol = gridPositions[grid2][grid1];

                System.out.println("Debug: Adding C(n,2) grid at (" + baseRow + ", " + baseCol + ")");

                for (int i = 0; i < gridSizePerBox; i++) {
                    for (int j = 0; j < gridSizePerBox; j++) {
                        Button cell = new Button("");
                        cell.setMinSize(40, 40);

                        int actualRow = baseRow + i;  // use baseRow to make sure the position of  C(n,2)
                        int actualCol = baseCol + j;  // use baseCol to make sure the position of  C(n,2)

                        mainGrid.add(cell, actualCol, actualRow);
                    }
                }
            }
        }

        // update UI
        if (logicGridContainer != null) {
            logicGridContainer.getChildren().clear();
            logicGridContainer.getChildren().add(mainGrid);
        } else {
            System.err.println("logicGridContainer is null! Cannot update UI");
        }
    }

    /** 显示 Clues**
    private void displayClues() {
        List<String> clues = puzzleManager.getClues();
        StringBuilder clueText = new StringBuilder();
        for (int i = 0; i < clues.size(); i++) {
            clueText.append("Clue #").append(i + 1).append(": ").append(clues.get(i)).append("\n");
        }
        clueLabel.setText(clueText.toString());
    }
     */
    /** 撤销上一步** */
    @FXML
    private void undoLastAction() {
        System.out.println("Undo Last Action!");
        puzzleManager.undoLastAction();
    }

    /** 清除错误** */
    @FXML
    private void clearErrors() {
        System.out.println("Clear Errors!");
        puzzleManager.clearErrors();
    }

    /** 重新开始*/
    @FXML
    private void restartPuzzle() {
        System.out.println("Restart Puzzle!");
        puzzleManager.restartGame();
        renderGrid();
        //displayClues();
    }

    /** 提交 Puzzle**   */
    @FXML
    private void submitPuzzle() {
        System.out.println("Submitting Puzzle...");
        /*
        boolean isCorrect = puzzleManager.submitPuzzle();

        if (isCorrect) {
            long elapsedTime = puzzleManager.getElapsedTime();
            showAlert(" Correct!", "You completed the puzzle in " + elapsedTime + " seconds!");
        } else {
            showAlert("Incorrect!", "Some answers are incorrect, please check again.");
        }
        */

    }


    /** 显示提示框** */
    private void showAlert(String title, String message) {
        javafx.scene.control.Alert alert = new javafx.scene.control.Alert(javafx.scene.control.Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    /** 获取 Hint** */
    @FXML
    private void handleHint() {
        System.out.println("Hint button clicked!");
        String hint = puzzleManager.getNextHint();
        showAlert("Hint:", hint);
    }
}