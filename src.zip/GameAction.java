public class GameAction {// for undo function
    private GameCell cell;
    private int prevState;
    private int newState;

    public GameAction(GameCell cell, int prevState, int newState) {
        this.cell = cell;
        this.prevState = prevState;
        this.newState = newState;
    }

    public void undo() {
        cell.setState(prevState);
    }
}
