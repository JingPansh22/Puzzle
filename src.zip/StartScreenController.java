import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

public class StartScreenController {
    @FXML private Button startPuzzleButton;
    @FXML private Label startScreenLabel;

    private String gridSize;
    private String difficulty;

    @FXML
    public void initialize() {
        startScreenLabel.setText("Welcome to the logic puzzle! Please click Start to begin.");
    }

    public void setPuzzleParameters(String gridSize, String difficulty) {
        this.gridSize = gridSize;
        this.difficulty = difficulty;
        if (startScreenLabel != null) {  // ✅ 确保 Label 已经初始化
            startScreenLabel.setText("A brand new " + gridSize + " puzzle has been initiated and is ready for you to begin.");
        }
    }

    @FXML
    public void handleStartPuzzle() {
        System.out.println("🚀 Starting the puzzle! Grid Size: " + gridSize + ", Difficulty: " + difficulty);

        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("puzzle.fxml"));
            Parent root = loader.load();

            PuzzleController puzzleController = loader.getController();
            puzzleController.initializeGame(gridSize, difficulty);  //

            Stage stage = (Stage) startPuzzleButton.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("❌ Error: Failed to load puzzle.fxml!");
        }
    }
}
