import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class CSVLoader {

    // load puzzle
    public static List<String[]> loadPuzzle(String fileName) {
        List<String[]> data = new ArrayList<>();
        try (InputStream is = CSVLoader.class.getClassLoader().getResourceAsStream(fileName);
             BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {

            if (is == null) {
                throw new RuntimeException(" Error: CSV file not found -> " + fileName);
            }

            String line;
            while ((line = br.readLine()) != null) {
                System.out.println(" Reading line: " + line);  // debug

                // parse CSV
                String[] values = line.split(",(?=([^\"]*\"[^\"]*\")*[^\"]*$)");

                // trim()
                for (int i = 0; i < values.length; i++) {
                    values[i] = values[i].trim().replaceAll("^\"|\"$", ""); // get rid of the ""
                }

                data.add(values);
                System.out.println("reading line: " + values); //debug
            }

        } catch (IOException e) {
            e.printStackTrace();
            throw new RuntimeException("Failed to load CSV: " + fileName);
        }

        // debug to see CSV file after parsing
        System.out.println("Parsed CSV Data:");
        for (String[] row : data) {
            System.out.println(Arrays.toString(row));
        }

        if (data.isEmpty()) {
            throw new RuntimeException(" Error: CSV file is empty -> " + fileName);
        }

        return data;
    }

    // load clues
    public static List<String> loadClues(String fileName) {
        List<String> clues = new ArrayList<>();

        try (InputStream is = CSVLoader.class.getClassLoader().getResourceAsStream(fileName)) {
            if (is == null) {
                throw new RuntimeException("Error: Clues CSV file not found -> " + fileName);
            }
            BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));

            String line;
            while ((line = br.readLine()) != null) {
                line = line.replace("\uFEFF", "").trim();  //!!!delete BOM character and space
                if (!line.isEmpty()) {
                    clues.add(line);
                }
            }
        } catch (Exception e) {
            System.err.println("Failed to load Clues: " + e.getMessage());
        }

        return clues;
    }


    // load hints
    public static List<String> loadHints(String fileName) {
        List<String> hints = new ArrayList<>();
        try (InputStream is = CSVLoader.class.getClassLoader().getResourceAsStream(fileName);
             BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {

            if (is == null) {
                throw new RuntimeException("Error: Hints CSV file not found -> " + fileName);
            }

            br.readLine(); // **跳过 CSV 头部**
            String line;
            while ((line = br.readLine()) != null) {
                hints.add(line.trim());
            }

        } catch (IOException e) {
            e.printStackTrace();
            throw new RuntimeException("Failed to load hints CSV: " + fileName);
        }

        System.out.println("Parsed Hints: " + hints);
        return hints;
    }
}

