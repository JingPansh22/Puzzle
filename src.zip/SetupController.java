import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.stage.Stage;
import javafx.scene.Parent;

import java.net.URL;
import java.util.ResourceBundle;

public class SetupController implements Initializable {
    @FXML private ComboBox<String> gridSizeComboBox;
    @FXML private ComboBox<String> difficultyComboBox;

    private static String selectedGridSize;  // save Grid Size
    private static String selectedDifficulty;  // save difficulty

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        System.out.println("Initializing SetupController...");

        // grid size options
        gridSizeComboBox.getItems().addAll("3x4", "3x5", "4x4", "4x5", "4x6", "4x7");

        // grid difficulty options
        difficultyComboBox.getItems().addAll("Easy", "Moderate", "Challenging");

        System.out.println("GridSize ComboBox populated!");
        System.out.println("Difficulty ComboBox populated!");
    }

    @FXML
    public void handleCreatePuzzle() {
        System.out.println("🎯 handleCreatePuzzle() called!");

        selectedGridSize = gridSizeComboBox.getValue();
        selectedDifficulty = difficultyComboBox.getValue();

        if (selectedGridSize == null || selectedDifficulty == null) {
            System.err.println("❌ Please select both grid size and difficulty!");
            return;
        }

        System.out.println("Selected Grid Size: " + selectedGridSize);
        System.out.println("Selected Difficulty: " + selectedDifficulty);

        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("startScreen.fxml"));
            Parent root = loader.load();

            StartScreenController startScreenController = loader.getController();
            startScreenController.setPuzzleParameters(selectedGridSize, selectedDifficulty); // ✅ 传递参数

            Stage stage = (Stage) gridSizeComboBox.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ✅ **提供静态方法，方便其他 Controller 访问难度和 Grid Size**
    public static String getSelectedGridSize() {
        return selectedGridSize;
    }

    public static String getSelectedDifficulty() {
        return selectedDifficulty;
    }
}
